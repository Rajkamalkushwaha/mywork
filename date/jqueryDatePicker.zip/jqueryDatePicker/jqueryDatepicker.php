<html lang="en">
<head>
  <meta charset="utf-8">
   <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css">
   <script src="//code.jquery.com/jquery-1.12.4.js"></script>
   <script src="//code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
   <script src="spiceGems_datepicker.js"></script>
</head>
<body>
<div id="filters" class="">
               
				<h3  id="message"></h3>
                    <div>
                        <input type="text" class="form-control" id="filter-date" >
						 <button onclick="IsEmpty()">save</button>
				 </div> 
				 <h4 style="color:red" id=errorval></h4>
            </div>


</body>
</html>